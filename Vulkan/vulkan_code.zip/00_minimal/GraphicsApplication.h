#pragma once

#include "vk_common.h"
#include "DeviceContext.h"
#include "RenderContext.h"

struct GLFWwindow;

struct VulkanGraphicsApplication
{
	const char* name;
	VulkanDeviceContext context;
	VulkanRenderContext rendercontext;
	GLFWwindow* window;

	//

	uint32_t m_imageIndex;
	uint32_t m_frame;
	uint32_t m_currentFrame;

	bool Initialize(const char *);
	bool Prepare();
	bool Run();
	bool Update();
	bool Begin();
	bool End();
	bool Display();
	void Terminate();
	bool Shutdown();
};
