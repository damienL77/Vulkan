
#include "vk_common.h"

#include "DeviceContext.h"
#include "RenderContext.h"
#include "GraphicsApplication.h"

//#define GLFW_INCLUDE_VULKAN
#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>

#define APP_NAME "00_minimal"

//
// Initialisation des ressources 
//

bool VulkanGraphicsApplication::Prepare()
{
	return true;
}

void VulkanGraphicsApplication::Terminate()
{

}

//
// Frame
//

bool VulkanGraphicsApplication::Begin()
{
	//TODO: a retirer
	vkDeviceWaitIdle(context.device);

	uint64_t timeout = UINT64_MAX;
	DEBUG_CHECK_VK(vkAcquireNextImageKHR(context.device, context.swapchain, timeout, VK_NULL_HANDLE/*acquire semaphore ici*/, VK_NULL_HANDLE, &m_imageIndex));

	return true;
}

bool VulkanGraphicsApplication::End()
{
	VkPresentInfoKHR presentInfo = {};
	presentInfo.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;
	presentInfo.waitSemaphoreCount = 0;		// OFF, pas forcement necessaire ici
	presentInfo.pWaitSemaphores = nullptr;// presentation semaphore ici synchro avec le dernier vkQueueSubmit;
	presentInfo.swapchainCount = 1;
	presentInfo.pSwapchains = &context.swapchain;
	presentInfo.pImageIndices = &m_imageIndex;
	DEBUG_CHECK_VK(vkQueuePresentKHR(rendercontext.presentQueue, &presentInfo));

	m_frame++;
	m_currentFrame = m_frame % rendercontext.PENDING_FRAMES;

	return true;
}

bool VulkanGraphicsApplication::Update()
{
	int width, height;
	glfwGetWindowSize(window, &width, &height);

	static double previousTime = glfwGetTime();
	static double currentTime = glfwGetTime();

	currentTime = glfwGetTime();
	double deltaTime = currentTime - previousTime;
	std::cout << "[" << m_frame << "] frame time = " << deltaTime*1000.0 << " ms [" << 1.0 / deltaTime << " fps]" << std::endl;
	previousTime = currentTime;

	float time = (float)currentTime;

	return true;
}

bool VulkanGraphicsApplication::Display()
{
	return true;
}

int main(void)
{
	/* Initialize the library */
	if (!glfwInit())
		return -1;
	glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API);

	VulkanGraphicsApplication app;

	/* Create a windowed mode window and its OpenGL context */
	app.window = glfwCreateWindow(1024, 768, APP_NAME, NULL, NULL);
	if (!app.window)
	{
		glfwTerminate();
		return -1;
	}

	app.Initialize(APP_NAME);

	/* Loop until the user closes the window */
	while (!glfwWindowShouldClose(app.window))
	{
		/* Render here */
		app.Run();

		/* Poll for and process events */
		glfwPollEvents();
	}

	app.Shutdown();

	glfwTerminate();
	return 0;
}
